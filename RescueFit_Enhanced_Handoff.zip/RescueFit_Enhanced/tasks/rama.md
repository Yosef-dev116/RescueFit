# Rama · Report, validation and pitch

Start with [TEAM_PLAN.md](../TEAM_PLAN.md), the supplied assignment and [docs/sources.md](../docs/sources.md).

1. Review the combined report draft and the six judging criteria. Keep local findings, computed scenario outputs and pilot hypotheses clearly labelled. Confirm the references and team attribution.
2. Ask for a past decision from a receiving kitchen. Capture what was offered, what the kitchen planned to serve, what could still be changed and what happened afterward. Use [docs/VALIDATION.md](../docs/VALIDATION.md).
3. Compare the operator's choice with RescueFit using the same information available at the time. Ask permission before including interviews or operational data in a submission.
4. Review [docs/business_model.md](../docs/business_model.md) with the group. Prioritize an institutional or network-sponsored pilot and a feasible support plan.
5. Add the team's verified screenshots or recorded walkthrough after browser review. Check the final report and timing with Yosef, then rehearse [docs/PITCH.md](../docs/PITCH.md).

The PEI statute is the **Donation of Food Act**. Confirm any operational procedure with the operator and applicable public health guidance. A proposed tax receipt workflow requires separate review.
