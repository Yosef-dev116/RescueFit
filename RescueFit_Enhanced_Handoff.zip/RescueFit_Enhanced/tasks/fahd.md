# Fahd · Data, model, impact and map

Start with [TEAM_PLAN.md](../TEAM_PLAN.md), then [model/ASSUMPTIONS.md](../model/ASSUMPTIONS.md). C3, C5 and C6 are the first review.

1. Review [docs/sources.md](../docs/sources.md) against the original workbook. Row 90 drives the reference counts and category mix. The fitted capacities and donor behaviour are scenario inputs.
2. Re-run the Python simulation, sensitivity cases and browser parity check. Pass the current figure values and main result to Rama.
3. Check that the map filters by range, storage and use window. In the sample, mark Stratford unavailable and verify the fallback. After saving, confirmation and transfer should be separate events.
4. Compare the **No alternates** case with the reference in the browser. Review unintended effects on unallocated food and ending inventory. Check that changing the random seed or offer mix changes the results.
5. Share the scenario PDF and figures for the report. The demo conversion uses mass-based meal equivalents, a local indicative purchase calculation and an optional sourced treatment scenario.

A donation forecast needs upstream offer records. Accuracy scoring needs labelled data and a specified intake model. Treat both as follow-up experiments until those inputs exist.
