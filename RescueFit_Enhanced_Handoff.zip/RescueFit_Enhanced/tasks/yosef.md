# Yosef · Intake and integration

Start with [TEAM_PLAN.md](../TEAM_PLAN.md) and [START_HERE.md](../START_HERE.md). Review C1, C2 and C4 before merging any route changes in the team app.

1. Try the default carrot lot, then parse **12 kg carrots, 4 kg potatoes, 20 rolls**. Check that the rolls need a measured quantity and that draft input cannot create an approved allocation by itself.
2. Confirm the fit uses existing stock first, enforces meal dates, keeps storage and prep limits separate and deducts only uncommitted purchases once per ingredient. Test a smaller staff budget and a whole-lot pickup.
3. Save the use-first plan, record a handoff and then record prep use. Verify the saved quantities in the ledger export.
4. Follow [docs/INTEGRATION.md](../docs/INTEGRATION.md) to add the self-contained dashboard to the team app. Review the shared Git changes in the team's usual workflow.
5. After review, record the demo with Fahd. Check Rama's submitted files and manage the official email.

For later assisted intake, verify the selected provider model and privacy terms. Keep credentials on the server. Returned photo or label text is a draft. The router uses staff-confirmed quantity, storage and timing.
