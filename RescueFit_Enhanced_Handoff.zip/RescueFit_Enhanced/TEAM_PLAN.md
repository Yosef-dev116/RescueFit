# RescueFit team plan

**IMPAC 2026 Innovation Stream · Yosef, Rama and Fahd**

The team targets **9:00 p.m. Atlantic on Friday, November 20** for submission. Holland College's deadline is **11:59 p.m. Atlantic** that night. See the [official competition page](https://hollandcollege.com/about/applied-research/impac/).

## The pitch

A receiving kitchen often has to decide how much unexpected surplus it can put into planned meals. RescueFit links that decision to the kitchen's stock, storage, prep capacity and adjustable purchases. For an already-collected lot, the tool keeps any additional weight in the ledger while staff confirm or release a possible handoff.

Second Harvest already supports donation matching and pickup. Wageningen University and Research has published optimization research combining donation acceptance and menu planning. This prototype applies those ideas to a workflow a small receiving kitchen could test in PEI. The team should validate the advantage over that kitchen's current process.

## Build and review order

| Order | Scope | Implementation in this bundle | Owner |
| --- | --- | --- | --- |
| C1 | Intake | Text parsing, measured units, counted items awaiting weigh-in, photo attachment and optional browser label reading | Yosef |
| C2 | Fit check | Storage, adjustable purchases, confirmed use window, three-day meal needs and daily prep budgets | Yosef |
| C3 | Redirect | Select a modeled site, change availability and log separate recipient confirmation and handoff | Fahd |
| C4 | Use-first plan | Five recipe entries, adjustable portions, meal allocations, shopping adjustment and recorded outcomes | Yosef |
| C5 | Impact | Live charts, full mass balance, transfer quantities and clearly labelled conversions | Fahd |
| C6 | Paired simulation | 30 days, 81 synthetic donors, 22 synthetic kitchens and 100 reference runs. Editable assumptions and day replay | Fahd |
| C7 | Report | Draft combined executive summary and report with companion guide and scenario method | Rama |

Do the short review in [START_HERE.md](START_HERE.md) in this order. Team ownership and review are especially important when merging into the shared repo.

## What distinguishes the build

| Judging criterion | Evidence to present |
| --- | --- |
| Problem Definition | PEI consultation reports redistributed food going unused. Confirm a comparable decision with one actual receiving kitchen. |
| Innovation | The same lot links approval, purchases, recipient confirmation and recorded use. Compare the workflow with the operator's spreadsheet or practice. |
| Solution Design | Demonstrate the same 12 kg through intake, fit, map, meal planning and outcome logging. |
| Impact & Value Creation | Compare identical offers and show used, unallocated, expired and remaining quantities together. |
| Feasibility & Adoption | The static demo is easy to share. Pilot with a single receiving kitchen and review work required per decision. |
| Growth & Sustainability | Begin with partner support and a narrow pilot. Measure support burden and adoption before assuming revenue. |

## Extra work after the core

- **Donation forecasting:** use dated eligible offer weights. The workbook's waste datasets describe different outcomes. The evaluation scaffold is in **model/forecast_offers.py**.
- **Photo evaluation:** collect permissioned, labelled intake photos and assess identification and abstention. Weight estimates need independently weighed lots. Trained staff provide safety and use-window information.
- **Barcode lookup:** optional product metadata after intake. Current fit calculations use reviewed inputs.
- **Partner validation:** Rama records whether an operator could change a past decision and how much effort it took. Contact and release of quotations require the team's coordination.
- **Walkthrough and pitch:** use [docs/PITCH.md](docs/PITCH.md) once the team has tried the new version.
- **Deployment:** use the standalone page as a static demonstration or copy it into the team Next app. A live pilot also needs persistent shared records, site sign-off and operational validation.

## Submission review

1. Reproduce the current reference and sensitivity results. Freeze these numbers for the report.
2. Check the final demo path in a normal browser. Review each file before incorporating it into the submission.
3. Verify the main file is **Innovation_RescueFit_1_Project.pdf** with an executive summary of at most 1.5 pages and a recommended 5–10 report pages. Include only supporting files the team has reviewed.
4. Use **Innovation_RescueFit_2_PrototypeGuide.pdf** and **Innovation_RescueFit_3_ScenarioModel.pdf** if useful. An optional hosted link or video can be included if the team has approved and created one.
5. Yosef submits to **jkmatters@hollandcollege.com** before the deadline. Keep attachments within 25 MB per email. If splitting emails, put the team name in each subject.

Use public data or data the team has the right to make public. The PDF linked from row 90 is cited and its aggregate figures are transcribed with attribution.
