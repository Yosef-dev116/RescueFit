import { redirect } from "next/navigation";

export default function ImpactPage() {
  redirect("/rescuefit/index.html#impact");
}
