import { redirect } from "next/navigation";

export default function NetworkPage() {
  redirect("/rescuefit/index.html#network");
}
