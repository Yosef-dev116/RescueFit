export type Storage = "fridge" | "freezer" | "dry";
export type Capacity = Record<Storage, number>;
export type Agency = {
  id: string;
  name: string;
  town: string;
  lat: number;
  lon: number;
  capacity_kg: Capacity;
  free_kg: Capacity;
  meals_per_day: number;
  diet_flags: string[];
};
export type Metrics = {
  kg_offered?: number;
  kg_received: number;
  kg_wasted_at_agency: number;
  meals: number;
  co2e_kg: number;
  cad: number;
  kg_used?: number;
  kg_unallocated?: number;
  kg_remaining?: number;
  kg_redirected?: number;
  kg_with_co2e_factor?: number;
  kg_with_cad_factor?: number;
  transfers?: number;
  redirect_kg_km?: number;
};
export type Scenario = {
  agencyWasteReduction?: { mean: number; p05: number; p95: number };

  days: number;
  donors: number;
  agencies: number;
  baseline: Metrics;
  fit_only?: Metrics;
  rescuefit: Metrics;
  daily: { day: number; baseline_waste_kg: number; rescuefit_waste_kg: number }[];
  assumptions: string[];
  seeds?: number | number[];
  runs?: number;
  dataset_status?: string;
};
function obj(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) throw new Error("Expected an object");
  return value as Record<string, unknown>;
}
function num(value: unknown, min = 0, max = Infinity): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max) throw new Error("Invalid number");
  return value;
}
function str(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) throw new Error("Invalid text");
  return value;
}
function strings(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is string => typeof item === "string" && !!item.trim());
}
function capacity(value: unknown): Capacity {
  const v = obj(value);
  return { fridge: num(v.fridge), freezer: num(v.freezer), dry: num(v.dry) };
}
export function parseAgencies(input: unknown): Agency[] {
  if (!Array.isArray(input)) throw new Error("Expected a list of agencies");
  const ids = new Set<string>();
  return input.map((item) => {
    const v = obj(item);
    const id = str(v.id);
    if (ids.has(id)) throw new Error("Duplicate agency ID");
    ids.add(id);
    const total = capacity(v.capacity_kg);
    const free = capacity(v.free_kg);
    for (const key of ["fridge", "freezer", "dry"] as const) if (free[key] > total[key]) throw new Error("Free space exceeds capacity");
    return { id, name: str(v.name), town: str(v.town), lat: num(v.lat, -90, 90), lon: num(v.lon, -180, 180), capacity_kg: total, free_kg: free, meals_per_day: num(v.meals_per_day), diet_flags: strings(v.diet_flags) };
  });
}
function parseMetrics(input: unknown): Metrics {
  const v = obj(input);
  const optional = (key: string) => v[key] === undefined ? undefined : num(v[key]);
  return { kg_received: num(v.kg_received), kg_wasted_at_agency: num(v.kg_wasted_at_agency),
    meals: num(v.meals), co2e_kg: num(v.co2e_kg), cad: num(v.cad), kg_offered: optional("kg_offered"),
    kg_used: optional("kg_used"), kg_unallocated: optional("kg_unallocated"), kg_remaining: optional("kg_remaining"),
    kg_redirected: optional("kg_redirected"), kg_with_co2e_factor: optional("kg_with_co2e_factor"),
    kg_with_cad_factor: optional("kg_with_cad_factor"), transfers: optional("transfers"), redirect_kg_km: optional("redirect_kg_km") };
}
export function parseScenario(input: unknown): Scenario {
  const v = obj(input);
  const daily = Array.isArray(v.daily) ? v.daily.map((item) => {
    const d = obj(item);
    return { day: num(d.day, 1), baseline_waste_kg: num(d.baseline_waste_kg), rescuefit_waste_kg: num(d.rescuefit_waste_kg) };
  }).sort((a, b) => a.day - b.day) : [];
  const seeds = Array.isArray(v.seeds) ? v.seeds.map((item) => num(item, -Infinity)) : typeof v.seeds === "number" ? num(v.seeds) : undefined;
  const uncertainty = v.uncertainty ? obj(v.uncertainty) : null;
  const paired = uncertainty?.paired_delta ? obj(uncertainty.paired_delta) : null;
  const interval = paired?.kg_wasted_at_agency_reduction ? obj(paired.kg_wasted_at_agency_reduction) : null;
  const agencyWasteReduction = interval ? { mean: num(interval.mean, -Infinity), p05: num(interval.p05, -Infinity), p95: num(interval.p95, -Infinity) } : undefined;
  if (agencyWasteReduction && agencyWasteReduction.p05 > agencyWasteReduction.p95) throw new Error("Invalid interval");
  return { agencyWasteReduction, days: num(v.days, 1), donors: num(v.donors), agencies: num(v.agencies),
    baseline: parseMetrics(v.baseline), fit_only: v.fit_only === undefined ? undefined : parseMetrics(v.fit_only),
    rescuefit: parseMetrics(v.rescuefit), daily, assumptions: strings(v.assumptions), seeds,
    dataset_status: typeof v.dataset_status === "string" ? v.dataset_status : typeof v.data_status === "string" ? v.data_status : undefined,
    runs: typeof v.runs === "number" ? num(v.runs) : undefined };
}
export function distanceKm(from: Pick<Agency, "lat" | "lon">, to: Pick<Agency, "lat" | "lon">): number {
  const rad = (degrees: number) => degrees * Math.PI / 180;
  const a = Math.sin(rad(to.lat - from.lat) / 2) ** 2 + Math.cos(rad(from.lat)) * Math.cos(rad(to.lat)) * Math.sin(rad(to.lon - from.lon) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(a)));
}

export const formatNumber = new Intl.NumberFormat("en-CA", { maximumFractionDigits: 1 });
export const formatMoney = new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD", maximumFractionDigits: 0 });

export type DemoLot = {
  lot_id: string;
  food: string;
  storage: Storage;
  offered_kg: number;
  collected_kg: number;
  kitchen_need_kg: number;
  kitchen_on_hand_kg: number;
  kitchen_allocated_kg: number;
  onward_pending_kg: number;
  onward_transferred_kg: number;
  shopping_reduction_kg: number;
  source_agency_id: string;
  suggested_agency_id: string | null;
  status: string;
  assumptions: string[];
};

export function parseDemo(input: unknown): DemoLot {
  const v = obj(input);
  const storage = v.storage;
  if (storage !== "fridge" && storage !== "freezer" && storage !== "dry") throw new Error("Invalid storage");
  const offered = num(v.offered_kg);
  const collected = num(v.collected_kg);
  const allocated = num(v.kitchen_allocated_kg);
  const pending = num(v.onward_pending_kg);
  const transferred = num(v.onward_transferred_kg);
  const need = num(v.kitchen_need_kg);
  const onHand = num(v.kitchen_on_hand_kg);
  const reduction = num(v.shopping_reduction_kg);
  const tolerance = 1e-6;
  if (collected > offered + tolerance || allocated + pending + transferred > collected + tolerance || allocated > Math.max(0, need - onHand) + tolerance || reduction > allocated + tolerance) throw new Error("Unbalanced lot data");
  return { lot_id: str(v.lot_id), food: str(v.food), storage, offered_kg: offered, collected_kg: collected, kitchen_need_kg: need, kitchen_on_hand_kg: onHand, kitchen_allocated_kg: allocated, onward_pending_kg: pending, onward_transferred_kg: transferred, shopping_reduction_kg: reduction, source_agency_id: str(v.source_agency_id), suggested_agency_id: typeof v.suggested_agency_id === "string" ? v.suggested_agency_id : null, status: str(v.status), assumptions: strings(v.assumptions) };
}
