# RescueFit PEI

IMPAC 2026 Innovation Stream · Team RescueFit

Open **[demo/index.html](demo/index.html)** in a browser. It contains the complete example kitchen, map and simulation. No server, key or external data download is needed.

## See the complete decision

1. **Intake.** Open the reviewed example of 12 kg of already-collected carrots. The mixed-offer button shows how text with weights and counted items becomes draft lots. Enter the measured weight for counted items.
2. **Kitchen fit.** The soup service needs 8 kg and has 2 kg in stock. The prototype assigns 6 kg to the kitchen. Try changing storage, available prep or service portions.
3. **Redirect map.** Review destinations for the other 6 kg. Mark the first recipient unavailable to see the next feasible recommendation.
4. **Use-first plan.** Review the quantities for the next three days and changes to the shopping list. Save the plan. Return to the map to simulate the recipient's confirmation and then record the physical handoff. Record kitchen prep use or discard separately in the plan.
5. **Impact lab.** Select a scenario and click **Run simulation**. The browser computes new results. Compare the three policies, replay one seed by day and export JSON or CSV.
6. **Data sources.** Review what came from the workbook and open the public references.

**Quick demonstration:** After the reference run, choose **No alternates** and rerun it. The model will reduce expiry at the receiving kitchen but use slightly less food than storage only on average. Compare unallocated kilograms for both outcomes.

## Files to use

| File | Purpose |
| --- | --- |
| [TEAM_PLAN.md](TEAM_PLAN.md) | Revised build order and competition checklist |
| [tasks/yosef.md](tasks/yosef.md), [tasks/fahd.md](tasks/fahd.md), [tasks/rama.md](tasks/rama.md) | Role handoffs |
| [demo/index.html](demo/index.html) | Deployable, self-contained demo |
| [docs/INTEGRATION.md](docs/INTEGRATION.md) | Existing Next app and static hosting options |
| [docs/sources.md](docs/sources.md) | Workbook rows, source uses and limitations |
| [model/ASSUMPTIONS.md](model/ASSUMPTIONS.md) | Inputs, policy logic and mass accounting |
| [docs/Innovation_RescueFit_1_Project.pdf](docs/Innovation_RescueFit_1_Project.pdf) | Executive summary and project report draft for team review |
| [docs/Innovation_RescueFit_2_PrototypeGuide.pdf](docs/Innovation_RescueFit_2_PrototypeGuide.pdf) | Operator and judge walkthrough |
| [docs/Innovation_RescueFit_3_ScenarioModel.pdf](docs/Innovation_RescueFit_3_ScenarioModel.pdf) | Reproducible scenario evidence |
| [docs/Innovation_RescueFit_4_ModelWalkthrough.mp4](docs/Innovation_RescueFit_4_ModelWalkthrough.mp4) | Captioned explanation of the lot and policy comparison |
| [docs/PITCH.md](docs/PITCH.md) | Two-minute walkthrough and seven-minute pitch outline |

The first release runs on fictional kitchens, offers and recipes. Historical reporting informs the network counts and the category mix. Photo attachment is local to the browser and printed-label reading depends on browser support. Staff confirm weight, storage and the use window. The prototype saves the current demonstration in the browser and exports a decision and event ledger.

## Rebuild and verify

From this folder:

    python3 -m unittest discover -s model -p 'test_*.py'
    python3 model/simulate.py
    python3 model/sensitivity.py
    python3 model/build_demo.py
    node --test model/test_workspace.cjs

Python 3.10+ runs the scenario and the build without additional dependencies. Node 20+ runs the JavaScript checks. To regenerate the three PDFs and figures, install ReportLab and Matplotlib and run **python3 model/render_report.py**. The workbook audit is included. To recreate it from the supplied catalogue, install openpyxl and run **python3 model/audit_register.py /path/to/IMPAC_Datasets.xlsx**.

The sample case and generated comparison passed automated workflow checks. The browser preview could not be opened in the review environment. The accompanying MP4 illustrates the example and results. A laptop and phone click-through is still needed before recording a screen demonstration.
