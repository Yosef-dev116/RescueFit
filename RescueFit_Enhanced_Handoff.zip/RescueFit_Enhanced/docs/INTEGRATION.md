# Run and integrate RescueFit

## Fast path

Open **demo/index.html**. The page has embedded fixtures, the decision engine and the live simulation. Use the simulator without a network connection. The decision ledger is saved per browser when storage is available.

## Static hosting

Publish **demo/index.html** as the site's root **index.html** with a static host. For the Vercel option in the team plan, use **demo/** as the static directory, serve **index.html**, and use a plain static configuration. A repository whose root contains only this public demonstration page also works. No API key or build command is needed for the HTML file. Open the deployed site, click **Run simulation**, and verify the browser permits a worker or the chunked fallback before sharing its URL.

## Existing Next app

The handoff contains route integration files, while the team's Next project supplies its app shell and dependencies. Copy the generated **app/public/rescuefit/index.html** into **public/rescuefit/** of the team app. Link to it with **/rescuefit/index.html#intake**, **#fit**, **#network**, **#plan**, **#impact** or **#evidence**. The included network and impact route adapters open those tabs and retain the project route names. Review the diff before applying the adapters.

Use the Next app's own base path if served under a prefix. Re-run **python3 model/build_demo.py** after editing the source scripts, CSS, template or data.

## Data contract

| Path under app/public/data | Content |
| --- | --- |
| agencies.json | Synthetic site IDs, approximate coordinates, storage capacity and expected throughput |
| shelf_life.json | Category labels, keywords and synthetic remaining-use windows for the model |
| impact_factors.json | Meal-equivalent convention and optional factors. Unknown network factors remain null |
| demo.json | Compatible carrot example for existing consumers |
| kitchen_demo.json | Reviewed sample lot, simulated meal needs, stock and purchase inputs |
| pei_evidence.json | Transcribed historical signups and published aggregate food mix |
| impac_register_audit.json | Selected workbook rows and their evidence roles |
| scenario_config.json | Reference settings including seed and bounds |
| scenario_results.json | Four paired policies, mass, intervals, means by day and one replay |
| forecast.json | Empty array pending reviewed dated offer inputs and evaluated forecasts |

The generated HTML embeds the same input fixtures and reference output. A new run computes policies from those fixtures with its own settings.

## Moving beyond demonstration

For an operational pilot, agree on approvals, data retention, roles, verified partner capacity and actual food handling limits. Use shared authenticated records when multiple staff work together. Serialize reservations against inventory and make event retries idempotent. Do a supervised run using the kitchen's normal process before trusting a recommendation at intake.
